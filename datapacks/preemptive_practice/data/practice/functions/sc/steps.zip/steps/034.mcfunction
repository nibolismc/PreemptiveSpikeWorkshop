# 34/114: #1 Spider + #2 Silverfish, 2 chest(s) behind
scoreboard players set #layout sc_cfg 2
scoreboard players set #sp1 sc_cfg 2
scoreboard players set #sp2 sc_cfg 0
scoreboard players set #front sc_cfg 0
scoreboard players set #b1 sc_cfg 0
scoreboard players set #behind sc_cfg 2
function practice:sc/apply
