# 6/114: Silverfish, 1 chest(s) behind
scoreboard players set #layout sc_cfg 1
scoreboard players set #sp1 sc_cfg 0
scoreboard players set #sp2 sc_cfg 5
scoreboard players set #front sc_cfg 0
scoreboard players set #b1 sc_cfg 0
scoreboard players set #behind sc_cfg 1
function practice:sc/apply
